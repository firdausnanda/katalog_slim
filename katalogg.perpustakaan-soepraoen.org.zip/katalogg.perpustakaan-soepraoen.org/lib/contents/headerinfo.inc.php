<?php 
/*
This page is intentionally left blank. Because the main content of headerinfo
is in database. But it is for block in template, not for a page.
*/

header ("location:index.php");

