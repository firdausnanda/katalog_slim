<?php
$sysconf['template']['base'] = 'php';
$sysconf['template']['responsive'] = true;
