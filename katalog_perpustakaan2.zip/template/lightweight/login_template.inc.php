<!DOCTYPE html>
<html>
<head><title><?php echo $page_title; ?></title><meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="webicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="webicon.ico" type="image/x-icon" />
<link href="<?php echo $sysconf['template']['css']; ?>" rel="stylesheet" type="text/css" />
<link href="template/default/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php echo $main_content; ?>
</body>
</html>
