<div class="footer">
Slims Installer Powered By <a href='http://www.apphp.com/php-easyinstaller/index.php' style="color: #bb5500" target="_blank">PHP Easy Installer</a> | <a href="license/GNULicense.html" target="_blank">Lisence</a>
</div>
