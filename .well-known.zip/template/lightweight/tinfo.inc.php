<?php
$sysconf['template']['base'] = 'php';
$sysconf['template']['responsive'] = false;
